SET search_path = public;

DROP FUNCTION gp_heap_distribution_check(text);

DROP FUNCTION gp_distribution_policy_heap_table_check(oid, smallint[]);
