-- drop the function as create_function.sql messes with catalog causing
-- gpcheckcat to fail if run post this.
DROP FUNCTION readindex(oid);
