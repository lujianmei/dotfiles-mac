
-- zlib is disabled

